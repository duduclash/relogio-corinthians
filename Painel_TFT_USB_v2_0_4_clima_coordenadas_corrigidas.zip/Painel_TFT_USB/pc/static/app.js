let settings = {};
let rules = [];
let currentMode = 'HOME';
let connected = false;
let toastTimer = null;
let musicCoverVersion = -1;

const $ = (id) => document.getElementById(id);

function toast(message, error = false) {
  const el = $('toast');
  el.textContent = message;
  el.style.borderColor = error ? '#8e454c' : '#385f93';
  el.style.background = error ? '#351f27' : '#182a42';
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2800);
}

function showPage(name) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.page === name));
  $('page-' + name).classList.add('active');
  const titles = {dashboard:'Visão geral',display:'Display',automation:'Automação',connection:'Conexão USB'};
  $('page-title').textContent = titles[name];
  $('breadcrumb').textContent = 'PAINEL / ' + titles[name].toUpperCase();
}
document.querySelectorAll('.nav-item').forEach(btn => btn.addEventListener('click', () => showPage(btn.dataset.page)));

function labelMode(mode) {
  const labels = {
    HOME: 'Padrão: Relógio, Corinthians e Clima',
    PCMON: 'PC Monitor',
    MUSIC: 'Música',
    WORK: 'Work'
  };
  return labels[mode] || 'Padrão: Relógio, Corinthians e Clima';
}

function renderMode(mode) {
  currentMode = mode;
  $('current-mode-name').textContent = labelMode(mode);
  ['HOME', 'PCMON', 'MUSIC', 'WORK'].forEach(item => {
    $('mode-' + item.toLowerCase()).classList.toggle('selected', mode === item);
  });
}

function renderConnection(data) {
  connected = !!data.connected;
  $('top-status').className = 'status-pill ' + (connected ? 'online' : 'offline');
  $('top-status').innerHTML = '<i></i> ' + (connected ? 'Conectado' : 'Desconectado');
  $('side-dot').classList.toggle('online', connected);
  $('side-device').textContent = connected ? 'ESP32 conectado' : 'ESP32 desconectado';
  $('side-port').textContent = connected ? data.port : 'Nenhuma porta selecionada';
  $('connection-dot').classList.toggle('online', connected);
  $('connection-title').textContent = connected ? 'ESP32 conectado' : 'Aguardando conexão';
  $('connection-description').textContent = connected ? 'Comunicação serial ativa.' : 'Conecte o ESP32 pela USB.';
  $('connection-port').textContent = connected ? data.port : '--';
  $('connect-button').disabled = connected;
  $('disconnect-button').disabled = !connected;
  $('test-button').disabled = !connected;
  $('port-select').disabled = connected;
}

function renderStatus(data) {
  renderConnection(data);
  renderMode(data.mode || 'HOME');
  $('control-mode-label').textContent = data.mode_control === 'automatic' ? 'Automático' : 'Manual';
  $('foreground-label').textContent = data.foreground_process || '-';
  if (data.error) $('connection-message').textContent = data.error;
  renderMetrics(data.data || {});
  renderMusic(data.music || {});
  renderWork(data.work || {});
  renderWeather(data.weather || {});
  renderWeatherAlert(data.alert || {});
}

function setMetric(valueId, barId, value, unit='') {
  const el = $(valueId);
  if (value === null || value === undefined || value < 0) {
    el.textContent = '--';
    if (barId) $(barId).style.width = '0%';
    return;
  }
  el.textContent = value;
  if (barId) $(barId).style.width = Math.max(0, Math.min(100, Number(value))) + '%';
}

function renderMetrics(d) {
  setMetric('metric-cpu', 'bar-cpu', d.cpu);
  setMetric('metric-gpu', 'bar-gpu', d.gpu);
  if (d.gpu === -1) $('gpu-unit').textContent = 'N/D'; else $('gpu-unit').textContent = '%';
  setMetric('metric-ram', 'bar-ram', d.ram_percent);
  $('ram-detail').textContent = `${d.ram_used_gb ?? '--'} / ${d.ram_total_gb ?? '--'} GB`;
  $('metric-disk').textContent = d.disk_free_gb ?? '--';
  $('metric-download').textContent = d.download_mbps === undefined ? '--' : Number(d.download_mbps).toFixed(2);
  $('metric-upload').textContent = d.upload_mbps === undefined ? '--' : Number(d.upload_mbps).toFixed(2);
  $('metric-uptime').textContent = d.uptime || '--';
  if (d.updated_at) $('data-updated').textContent = 'Atualizado ' + new Date(d.updated_at * 1000).toLocaleTimeString('pt-BR');
}

function renderMusic(data) {
  $('music-title').textContent = data.title || 'Nenhuma mídia';
  $('music-artist').textContent = data.artist || 'Abra Spotify ou outro player';
  $('music-status').textContent = data.status || 'SEM MÍDIA';
  $('music-toggle-button').textContent = data.playing ? 'Pausar' : 'Reproduzir';
  $('music-status').classList.toggle('playing', !!data.playing);

  const version = Number(data.cover_version || 0);
  if (version !== musicCoverVersion) {
    musicCoverVersion = version;
    const cover = $('media-cover');
    const image = $('music-cover-image');
    if (data.has_cover && version > 0) {
      image.src = `/api/music/cover?v=${version}`;
      image.alt = `Capa do álbum: ${data.album || data.title || 'Música atual'}`;
      cover.classList.add('has-image');
    } else {
      image.removeAttribute('src');
      image.alt = 'Sem capa disponível';
      cover.classList.remove('has-image');
    }
  }
}

function formatarTempo(segundos) {
  const total = Math.max(0, Number(segundos) || 0);
  const minutos = Math.floor(total / 60);
  const resto = total % 60;
  return String(minutos).padStart(2, '0') + ':' + String(resto).padStart(2, '0');
}

function renderWork(data) {
  $('work-phase').textContent = data.phase || 'FOCO';
  $('work-time').textContent = formatarTempo(data.remaining ?? 1500);
  $('work-cycles').textContent = data.cycles ?? 0;
  $('work-tool-panel').classList.toggle('work-break', data.phase === 'PAUSA');
}

function renderWeather(data) {
  const status = $('weather-status');
  if (!status) return;
  if (data.available) {
    const atualizado = data.updated_at ? new Date(data.updated_at * 1000).toLocaleTimeString('pt-BR') : '--:--';
    status.textContent = data.stale
      ? `Última previsão salva para ${data.city}, de ${atualizado}. Sem atualização recente.`
      : `Clima recebido para ${data.city}. Atualizado às ${atualizado}.`;
  } else {
    status.textContent = data.error || 'Aguardando primeira consulta do clima.';
  }
}

function renderWeatherAlert(data) {
  const status = $('weather-alert-status');
  if (!status) return;
  if (data.active) {
    status.textContent = `AVISO ATIVO · ${data.title || 'Consulte o aviso'}`;
    status.style.color = '#78BFFF';
  } else {
    status.textContent = data.error || 'Nenhum aviso ativo para este município.';
    status.style.color = '';
  }
}

async function refreshWeather() {
  try {
    const cfg = readSettingsForm();
    const saved = await api('/api/settings', {method:'POST', body:JSON.stringify(cfg)});
    settings = saved.settings;
    await api('/api/weather/refresh', {method:'POST'});
    toast('Localização salva. Atualização do clima solicitada.');
  } catch (e) { toast(e.message, true); }
}

async function controlMusic(action) {
  try {
    const data = await api('/api/music/control', {method:'POST', body:JSON.stringify({action})});
    renderMusic(data.music || {});
    toast('Comando de mídia enviado.');
  } catch (e) { toast(e.message, true); }
}

async function controlWork(action) {
  try {
    const data = await api('/api/work/control', {method:'POST', body:JSON.stringify({action})});
    renderWork(data.work || {});
    const labels = {start:'Cronômetro iniciado.', pause:'Cronômetro pausado.', reset:'Cronômetro reiniciado.'};
    toast(labels[action]);
  } catch (e) { toast(e.message, true); }
}

async function api(url, options={}) {
  const response = await fetch(url, {headers:{'Content-Type':'application/json'}, ...options});
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Falha na solicitação.');
  return data;
}

async function refreshStatus() {
  try { renderStatus(await api('/api/status')); } catch (e) { $('connection-message').textContent = e.message; }
}

async function loadPorts() {
  try {
    const data = await api('/api/ports');
    const select = $('port-select');
    const previous = select.value;
    select.innerHTML = '';
    data.ports.forEach(p => {
      const option = document.createElement('option');
      option.value = p.device;
      option.textContent = `${p.device} · ${p.description}`;
      select.appendChild(option);
    });
    if ([...select.options].some(o => o.value === previous)) select.value = previous;
    if (!data.ports.length) select.add(new Option('Nenhuma porta serial encontrada', ''));
  } catch (e) { $('connection-message').textContent = e.message; }
}

async function connectDevice() {
  const port = $('port-select').value;
  if (!port) return toast('Selecione uma porta COM.', true);
  $('connect-button').disabled = true;
  $('connection-message').textContent = 'Conectando e sincronizando configurações...';
  try {
    const data = await api('/api/connect', {method:'POST', body:JSON.stringify({port})});
    toast('ESP32 conectado em ' + data.port);
    await refreshStatus();
  } catch (e) {
    $('connection-message').textContent = e.message;
    toast(e.message, true);
  } finally { $('connect-button').disabled = connected; }
}

async function disconnectDevice() {
  try {
    await api('/api/disconnect', {method:'POST'});
    await refreshStatus();
    toast('ESP32 desconectado.');
  } catch (e) { toast(e.message, true); }
}

async function testUsb() {
  try {
    const data = await api('/api/test', {method:'POST'});
    $('connection-message').textContent = data.message;
    toast(data.message);
  } catch (e) { $('connection-message').textContent = e.message; toast(e.message, true); }
}

async function setMode(mode) {
  if (!connected) { showPage('connection'); return toast('Conecte o ESP32 antes de trocar o modo.', true); }
  try {
    await api('/api/mode', {method:'POST', body:JSON.stringify({mode})});
    $('control-mode-label').textContent = 'Manual';
    $('manual-choice').classList.add('active');
    $('automatic-choice').classList.remove('active');
    settings.mode_control = 'manual';
    renderMode(mode);
    toast('Modo ativado: ' + labelMode(mode));
  } catch (e) { toast(e.message, true); }
}

function populateSettings(cfg) {
  settings = cfg;
  $('brightness-auto').checked = !!cfg.brightness_auto;
  $('brightness-day').value = cfg.brightness_day;
  $('brightness-night').value = cfg.brightness_night;
  $('night-start').value = cfg.night_start;
  $('night-end').value = cfg.night_end;
  $('home-interval').value = cfg.home_interval;
  $('pcmon-interval').value = cfg.pcmon_interval;
  $('data-interval').value = cfg.data_interval;
  $('gpu-interval').value = cfg.gpu_interval;
  $('weather-city').value = cfg.weather_city || 'Sorocaba, SP';
  $('weather-enabled').checked = cfg.weather_enabled !== false;
  $('weather-show-forecast').checked = cfg.weather_show_forecast !== false;
  $('weather-show-details').checked = cfg.weather_show_details !== false;
  $('weather-show-city').checked = cfg.weather_show_city !== false;
  $('weather-unit').value = cfg.weather_unit || 'C';
  $('weather-background').value = cfg.weather_background || 'navy';
  $('weather-accent').value = cfg.weather_accent || 'blue';
  $('weather-page-seconds').value = cfg.weather_page_seconds ?? 7;
  $('weather-refresh-minutes').value = cfg.weather_refresh_minutes ?? 30;
  $('weather-alerts-enabled').checked = cfg.weather_alerts_enabled !== false;
  $('alert-page-seconds').value = cfg.alert_page_seconds ?? 5;
  $('alert-refresh-minutes').value = cfg.alert_refresh_minutes ?? 10;
  $('focus-minutes').value = cfg.focus_minutes ?? 25;
  $('break-minutes').value = cfg.break_minutes ?? 5;
  $('fallback-mode').value = cfg.fallback_mode;
  $('brightness-day-value').textContent = cfg.brightness_day;
  $('brightness-night-value').textContent = cfg.brightness_night;
  $('brightness-summary').textContent = `${cfg.brightness_night}/255 entre ${cfg.night_start} e ${cfg.night_end}`;
  setControlButtons(cfg.mode_control);
  rules = Array.isArray(cfg.rules) ? cfg.rules.map(r => ({...r})) : [];
  renderRules();
}

function readSettingsForm() {
  return {
    ...settings,
    brightness_auto: $('brightness-auto').checked,
    brightness_day: Number($('brightness-day').value),
    brightness_night: Number($('brightness-night').value),
    night_start: $('night-start').value,
    night_end: $('night-end').value,
    home_interval: Number($('home-interval').value),
    pcmon_interval: Number($('pcmon-interval').value),
    data_interval: Number($('data-interval').value),
    gpu_interval: Number($('gpu-interval').value),
    weather_city: $('weather-city').value.trim(),
    weather_enabled: $('weather-enabled').checked,
    weather_show_forecast: $('weather-show-forecast').checked,
    weather_show_details: $('weather-show-details').checked,
    weather_show_city: $('weather-show-city').checked,
    weather_unit: $('weather-unit').value,
    weather_background: $('weather-background').value,
    weather_accent: $('weather-accent').value,
    weather_page_seconds: Number($('weather-page-seconds').value),
    weather_refresh_minutes: Number($('weather-refresh-minutes').value),
    weather_alerts_enabled: $('weather-alerts-enabled').checked,
    alert_page_seconds: Number($('alert-page-seconds').value),
    alert_refresh_minutes: Number($('alert-refresh-minutes').value),
    focus_minutes: Number($('focus-minutes').value),
    break_minutes: Number($('break-minutes').value),
    fallback_mode: $('fallback-mode').value,
    rules: rules,
  };
}

async function saveSettings() {
  const cfg = readSettingsForm();
  try {
    const data = await api('/api/settings', {method:'POST', body:JSON.stringify(cfg)});
    populateSettings(data.settings);
    const message = data.sent_to_display ? 'Salvo no PC e enviado ao ESP32.' : 'Salvo no PC. Será enviado ao conectar o ESP32.';
    $('display-save-hint').textContent = message;
    $('automation-save-hint').textContent = message;
    toast(message);
  } catch (e) { toast(e.message, true); }
}

function setControlButtons(mode) {
  $('manual-choice').classList.toggle('active', mode !== 'automatic');
  $('automatic-choice').classList.toggle('active', mode === 'automatic');
  $('control-mode-label').textContent = mode === 'automatic' ? 'Automático' : 'Manual';
}

async function setControlMode(mode) {
  settings.mode_control = mode;
  setControlButtons(mode);
  await saveSettings();
  if (mode === 'automatic') toast('Automação ativada. O modo acompanha o aplicativo em primeiro plano.');
}

function renderRules() {
  const list = $('rule-list');
  list.innerHTML = '';
  $('rule-count').textContent = `${rules.length} ${rules.length === 1 ? 'regra' : 'regras'}`;
  $('rules-empty').style.display = rules.length ? 'none' : 'block';
  rules.forEach((rule, index) => {
    const row = document.createElement('div');
    row.className = 'rule-item';
    const name = document.createElement('div');
    name.className = 'rule-process';
    name.textContent = rule.process;
    const select = document.createElement('select');
    select.innerHTML = '<option value="PCMON">PC Monitor</option><option value="HOME">Padrão: Relógio, Corinthians e Clima</option><option value="MUSIC">Música</option><option value="WORK">Work</option>';
    select.value = rule.mode;
    select.addEventListener('change', () => { rules[index].mode = select.value; });
    const remove = document.createElement('button');
    remove.className = 'delete-rule';
    remove.title = 'Remover regra';
    remove.textContent = '×';
    remove.addEventListener('click', () => { rules.splice(index, 1); renderRules(); });
    row.append(name, select, remove);
    list.appendChild(row);
  });
}

function addRule() {
  const processName = $('new-process').value.trim();
  if (!processName) return toast('Digite o nome do processo .exe.', true);
  if (rules.length >= 12) return toast('Limite de 12 regras.', true);
  if (rules.some(r => r.process.toLowerCase() === processName.toLowerCase())) return toast('Esse processo já está cadastrado.', true);
  rules.push({process:processName, mode:$('new-process-mode').value});
  $('new-process').value = '';
  renderRules();
}

$('brightness-day').addEventListener('input', e => $('brightness-day-value').textContent = e.target.value);
$('brightness-night').addEventListener('input', e => $('brightness-night-value').textContent = e.target.value);
['brightness-night','night-start','night-end'].forEach(id => $(id).addEventListener('input', () => {
  $('brightness-summary').textContent = `${$('brightness-night').value}/255 entre ${$('night-start').value} e ${$('night-end').value}`;
}));
$('refresh-btn').addEventListener('click', () => { refreshStatus(); loadPorts(); toast('Dados atualizados.'); });

async function init() {
  try { populateSettings(await api('/api/settings')); } catch (e) { toast('Não foi possível carregar as configurações.', true); }
  await loadPorts();
  await refreshStatus();
  setInterval(refreshStatus, 1800);
  setInterval(loadPorts, 10000);
}
init();
