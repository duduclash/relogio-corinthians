from flask import Flask, Response, jsonify, render_template, request
import asyncio
import base64
import csv
import ctypes
import json
import io
import os
import re
import subprocess
import threading
import time
import unicodedata
from pathlib import Path
from datetime import date, datetime
from zoneinfo import ZoneInfo
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import psutil
import serial
from serial.tools import list_ports

BASE_DIR = Path(__file__).resolve().parent
CONFIG_FILE = BASE_DIR / "settings.json"
WEATHER_CACHE_FILE = BASE_DIR / "weather_cache.json"
WEATHER_ICONS_DIR = BASE_DIR / "weather_icons_v203"
INMET_ALERTS_URL = "https://apiprevmet3.inmet.gov.br/avisos/ativos"

app = Flask(__name__)
porta_serial = None
trava_serial = threading.Lock()
trava_config = threading.Lock()
modo_atual = "HOME"
processo_atual = "-"

trava_musica = threading.Lock()
dados_musica = {
    "available": False,
    "playing": False,
    "title": "Nenhuma mídia",
    "artist": "Abra Spotify ou outro player",
    "album": "",
    "status": "SEM MIDIA",
    "position_ms": 0,
    "duration_ms": 0,
    "cover_version": 0,
    "has_cover": False,
}
capa_musica_jpeg = b""
capa_musica_rgb565 = b""
versao_capa_musica = 0
chave_capa_musica = ""
ultima_tentativa_capa = 0.0
forcar_sync_musica = False

trava_work = threading.Lock()
work_timer = {
    "phase": "FOCO",
    "remaining": 25 * 60,
    "total": 25 * 60,
    "running": False,
    "cycles": 0,
    "last_tick": time.monotonic(),
}
ultimo_erro = ""

trava_clima = threading.Lock()
dados_clima = {
    "available": False,
    "city": "Sorocaba - SP",
    "temperature": None,
    "apparent_temperature": None,
    "humidity": None,
    "wind_speed": None,
    "weather_code": None,
    "is_day": 1,
    "forecast": [],
    "updated_at": None,
    "error": "Aguardando primeira consulta",
}
clima_force_event = threading.Event()

trava_alerta = threading.Lock()
dados_alerta = {
    "active": False,
    "severity": 0,
    "title": "",
    "detail": "",
    "valid_until": "",
    "updated_at": None,
    "error": "Aguardando consulta ao INMET",
}

# Imagens oficiais do Google Weather, armazenadas em cache no PC.
# Cada item já fica convertido para RGB565 little-endian para o TFT.
icones_clima_rgb565 = {}


dados_monitor = {
    "cpu": 0,
    "gpu": -1,
    "ram_percent": 0,
    "ram_used_gb": 0,
    "ram_total_gb": 0,
    "download_mbps": 0,
    "upload_mbps": 0,
    "disk_free_gb": 0,
    "uptime": "--",
    "updated_at": None,
}

CONFIG_PADRAO = {
    "mode_control": "manual",
    "brightness_auto": True,
    "brightness_day": 255,
    "brightness_night": 35,
    "night_start": "00:30",
    "night_end": "05:00",
    "home_interval": 5,
    "pcmon_interval": 8,
    "data_interval": 1,
    "gpu_interval": 3,
    "focus_minutes": 25,
    "break_minutes": 5,
    "weather_city": "Sorocaba, SP",
    "weather_enabled": True,
    "weather_show_forecast": True,
    "weather_show_details": True,
    "weather_show_city": True,
    "weather_unit": "C",
    "weather_background": "navy",
    "weather_accent": "blue",
    "weather_page_seconds": 7,
    "weather_refresh_minutes": 30,
    "weather_alerts_enabled": True,
    "alert_refresh_minutes": 10,
    "alert_page_seconds": 5,
    "fallback_mode": "HOME",
    "rules": [
        {"process": "Fusion360.exe", "mode": "PCMON"},
        {"process": "acad.exe", "mode": "PCMON"},
        {"process": "Spotify.exe", "mode": "MUSIC"},
    ],
}


def carregar_configuracao():
    configuracao = dict(CONFIG_PADRAO)
    try:
        if CONFIG_FILE.exists():
            with CONFIG_FILE.open("r", encoding="utf-8") as arquivo:
                salva = json.load(arquivo)
            if isinstance(salva, dict):
                configuracao.update(salva)
    except (OSError, ValueError):
        pass
    return validar_configuracao(configuracao)


def validar_horario(valor, padrao):
    if not isinstance(valor, str) or not re.fullmatch(r"\d{2}:\d{2}", valor):
        return padrao
    hora, minuto = map(int, valor.split(":"))
    if hora > 23 or minuto > 59:
        return padrao
    return f"{hora:02d}:{minuto:02d}"


def numero(valor, minimo, maximo, padrao):
    try:
        return max(minimo, min(maximo, int(valor)))
    except (TypeError, ValueError):
        return padrao


def validar_configuracao(dados):
    cfg = dict(CONFIG_PADRAO)
    cfg["mode_control"] = "automatic" if dados.get("mode_control") == "automatic" else "manual"
    cfg["brightness_auto"] = bool(dados.get("brightness_auto", True))
    cfg["brightness_day"] = numero(dados.get("brightness_day"), 0, 255, 255)
    cfg["brightness_night"] = numero(dados.get("brightness_night"), 0, 255, 35)
    cfg["night_start"] = validar_horario(dados.get("night_start"), "00:30")
    cfg["night_end"] = validar_horario(dados.get("night_end"), "05:00")
    cfg["home_interval"] = numero(dados.get("home_interval"), 2, 60, 5)
    cfg["pcmon_interval"] = numero(dados.get("pcmon_interval"), 2, 60, 8)
    cfg["data_interval"] = numero(dados.get("data_interval"), 1, 5, 1)
    cfg["gpu_interval"] = numero(dados.get("gpu_interval"), 2, 15, 3)
    cfg["focus_minutes"] = numero(dados.get("focus_minutes"), 1, 120, 25)
    cfg["break_minutes"] = numero(dados.get("break_minutes"), 1, 60, 5)
    cidade_clima = str(dados.get("weather_city", "Sorocaba, SP")).strip()[:60]
    cfg["weather_city"] = cidade_clima or "Sorocaba, SP"
    cfg["weather_enabled"] = bool(dados.get("weather_enabled", True))
    cfg["weather_show_forecast"] = bool(dados.get("weather_show_forecast", True))
    cfg["weather_show_details"] = bool(dados.get("weather_show_details", True))
    cfg["weather_show_city"] = bool(dados.get("weather_show_city", True))
    cfg["weather_unit"] = "F" if dados.get("weather_unit") == "F" else "C"
    cfg["weather_background"] = "black" if dados.get("weather_background") == "black" else "navy"
    acentos_validos = ("blue", "cyan", "purple", "amber")
    cfg["weather_accent"] = dados.get("weather_accent") if dados.get("weather_accent") in acentos_validos else "blue"
    cfg["weather_page_seconds"] = numero(dados.get("weather_page_seconds"), 2, 30, 7)
    cfg["weather_refresh_minutes"] = numero(dados.get("weather_refresh_minutes"), 15, 180, 30)
    cfg["weather_alerts_enabled"] = bool(dados.get("weather_alerts_enabled", True))
    cfg["alert_page_seconds"] = numero(dados.get("alert_page_seconds"), 3, 20, 5)
    cfg["alert_refresh_minutes"] = numero(dados.get("alert_refresh_minutes"), 5, 60, 10)
    modos_validos = ("HOME", "PCMON", "MUSIC", "WORK")
    cfg["fallback_mode"] = dados.get("fallback_mode") if dados.get("fallback_mode") in modos_validos else "HOME"

    regras = dados.get("rules", CONFIG_PADRAO["rules"])
    cfg["rules"] = []
    if isinstance(regras, list):
        for regra in regras[:12]:
            if not isinstance(regra, dict):
                continue
            processo = str(regra.get("process", "")).strip()[:64]
            modo = regra.get("mode")
            if processo and modo in modos_validos:
                cfg["rules"].append({"process": processo, "mode": modo})
    return cfg


CONFIG = carregar_configuracao()
work_timer["remaining"] = CONFIG["focus_minutes"] * 60
work_timer["total"] = CONFIG["focus_minutes"] * 60


def _atualizar_work_locked():
    agora = time.monotonic()
    if work_timer["running"]:
        decorrido = int(agora - work_timer["last_tick"])
        if decorrido > 0:
            work_timer["remaining"] -= decorrido
            work_timer["last_tick"] += decorrido
            while work_timer["remaining"] <= 0:
                excedente = -work_timer["remaining"]
                if work_timer["phase"] == "FOCO":
                    work_timer["phase"] = "PAUSA"
                    duracao = CONFIG["break_minutes"] * 60
                else:
                    work_timer["phase"] = "FOCO"
                    work_timer["cycles"] += 1
                    duracao = CONFIG["focus_minutes"] * 60
                work_timer["total"] = duracao
                work_timer["remaining"] = max(1, duracao - excedente)
    return {
        "phase": work_timer["phase"],
        "remaining": max(0, int(work_timer["remaining"])),
        "total": max(1, int(work_timer["total"])),
        "running": bool(work_timer["running"]),
        "cycles": int(work_timer["cycles"]),
        "focus_minutes": CONFIG["focus_minutes"],
        "break_minutes": CONFIG["break_minutes"],
    }


def obter_work_timer():
    with trava_work:
        return _atualizar_work_locked()


def salvar_configuracao():
    with trava_config:
        temporario = CONFIG_FILE.with_suffix(".tmp")
        with temporario.open("w", encoding="utf-8") as arquivo:
            json.dump(CONFIG, arquivo, ensure_ascii=False, indent=2)
        temporario.replace(CONFIG_FILE)


def horario_para_minutos(valor):
    hora, minuto = map(int, valor.split(":"))
    return hora * 60 + minuto


def comando_configuracao():
    with trava_config:
        cfg = dict(CONFIG)
    inicio = horario_para_minutos(cfg["night_start"])
    fim = horario_para_minutos(cfg["night_end"])
    return (
        f"CFG:{1 if cfg['brightness_auto'] else 0},"
        f"{cfg['brightness_day']},{cfg['brightness_night']},"
        f"{inicio},{fim},{cfg['home_interval']},{cfg['pcmon_interval']}"
    )


def enviar_e_aguardar(comando, resposta_esperada, timeout=3):
    if porta_serial is None or not porta_serial.is_open:
        raise RuntimeError("ESP32 não está conectado.")

    with trava_serial:
        porta_serial.write((comando + "\n").encode("ascii"))
        limite = time.monotonic() + timeout
        while time.monotonic() < limite:
            linha = porta_serial.readline().decode("utf-8", errors="ignore").strip()
            if linha == resposta_esperada:
                return True
            if linha.startswith("NACK:"):
                raise RuntimeError("O ESP32 não reconheceu o comando.")
    raise RuntimeError("O ESP32 não respondeu. Confira o firmware e a porta COM.")


def comando_configuracao_clima():
    with trava_config:
        cfg = dict(CONFIG)
    acentos = {"blue": 0, "cyan": 1, "purple": 2, "amber": 3}
    campos = [
        1 if cfg["weather_enabled"] else 0,
        1 if cfg["weather_show_forecast"] else 0,
        1 if cfg["weather_show_details"] else 0,
        1 if cfg["weather_show_city"] else 0,
        1 if cfg["weather_unit"] == "F" else 0,
        acentos[cfg["weather_accent"]],
        cfg["weather_page_seconds"],
        1 if cfg["weather_alerts_enabled"] else 0,
        cfg["alert_page_seconds"],
        cfg["weather_refresh_minutes"],
        cfg["alert_refresh_minutes"],
        1 if cfg["weather_background"] == "black" else 0,
    ]
    return "WCFG:" + ",".join(str(valor) for valor in campos)


def enviar_configuracao_para_esp():
    if porta_serial is None or not porta_serial.is_open:
        return False
    enviar_e_aguardar(comando_configuracao(), "ACK:CFG")
    enviar_e_aguardar(comando_configuracao_clima(), "ACK:WCFG")
    return True


def comando_localizacao_clima(dados):
    try:
        latitude = float(dados.get("latitude"))
        longitude = float(dados.get("longitude"))
    except (TypeError, ValueError):
        return ""
    cidade = limpar_texto_alerta(dados.get("city", "Sorocaba - SP"), 23) or "Sorocaba - SP"
    return f"WEATHERLOC:{cidade}|{latitude:.5f}|{longitude:.5f}\n"


def enviar_localizacao_clima_para_esp(dados=None):
    if porta_serial is None or not porta_serial.is_open:
        return False
    if dados is None:
        with trava_clima:
            dados = dict(dados_clima)
    comando = comando_localizacao_clima(dados)
    if not comando:
        return False
    try:
        with trava_serial:
            if porta_serial is None or not porta_serial.is_open:
                return False
            porta_serial.write(comando.encode("ascii", errors="ignore"))
            porta_serial.flush()
        return True
    except Exception:
        return False


def requisicao_json(url, timeout=12):
    cabecalhos = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/130 Safari/537.36",
        "Accept": "application/json,text/plain,*/*",
    }
    if url.startswith(INMET_ALERTS_URL):
        cabecalhos["Referer"] = "https://avisos.inmet.gov.br/"
    requisicao = Request(url, headers=cabecalhos)
    with urlopen(requisicao, timeout=timeout) as resposta:
        return json.loads(resposta.read().decode("utf-8"))


def normalizar_texto_clima(texto):
    texto = unicodedata.normalize("NFKD", str(texto))
    return "".join(c for c in texto if not unicodedata.combining(c)).strip().casefold()


def buscar_clima_open_meteo(cidade):
    """Consulta previsão na Open-Meteo; não usa a Google Weather API."""
    cidade_busca = cidade.strip()
    if not cidade_busca:
        raise ValueError("Informe uma cidade para consultar o clima.")

    partes = [parte.strip() for parte in cidade_busca.split(",", 1)]
    nome_busca = partes[0]
    estado_busca = partes[1] if len(partes) > 1 else ""
    estados_br = {
        "AC": "Acre", "AL": "Alagoas", "AP": "Amapá", "AM": "Amazonas",
        "BA": "Bahia", "CE": "Ceará", "DF": "Distrito Federal", "ES": "Espírito Santo",
        "GO": "Goiás", "MA": "Maranhão", "MT": "Mato Grosso", "MS": "Mato Grosso do Sul",
        "MG": "Minas Gerais", "PA": "Pará", "PB": "Paraíba", "PR": "Paraná",
        "PE": "Pernambuco", "PI": "Piauí", "RJ": "Rio de Janeiro", "RN": "Rio Grande do Norte",
        "RS": "Rio Grande do Sul", "RO": "Rondônia", "RR": "Roraima", "SC": "Santa Catarina",
        "SP": "São Paulo", "SE": "Sergipe", "TO": "Tocantins",
    }
    estado_nome = estados_br.get(estado_busca.upper(), estado_busca)
    nome_geocodificacao = f"{nome_busca}, {estado_busca}" if estado_busca else nome_busca
    geocode_query = urlencode({
        "name": nome_geocodificacao,
        "count": 10,
        "language": "pt",
        "format": "json",
        "countryCode": "BR",
    })
    geocode = requisicao_json("https://geocoding-api.open-meteo.com/v1/search?" + geocode_query)
    resultados = geocode.get("results") or []
    if not resultados:
        raise ValueError(f"Cidade não encontrada: {nome_busca}")

    local = resultados[0]
    if estado_busca:
        estado_normalizado = normalizar_texto_clima(estado_nome)
        local = next(
            (item for item in resultados
             if normalizar_texto_clima(item.get("admin1", "")) == estado_normalizado),
            None,
        )
        if local is None:
            raise ValueError(f"Não encontrei {nome_busca} no estado {estado_busca}.")

    latitude = float(local["latitude"])
    longitude = float(local["longitude"])
    nome = str(local.get("name") or nome_busca)
    sigla_estado = estado_busca.upper() if len(estado_busca) == 2 else str(local.get("admin1") or "")
    cidade_exibicao = f"{nome} - {sigla_estado}" if sigla_estado else nome

    parametros = {
        "latitude": latitude,
        "longitude": longitude,
        "current": "temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,is_day,wind_speed_10m",
        "daily": "weather_code,temperature_2m_max,temperature_2m_min",
        "forecast_days": 4,
        "timezone": "auto",
    }
    previsao = requisicao_json("https://api.open-meteo.com/v1/forecast?" + urlencode(parametros))
    atual = previsao.get("current") or {}
    diario = previsao.get("daily") or {}
    campos_diarios = (
        diario.get("time") or [],
        diario.get("weather_code") or [],
        diario.get("temperature_2m_max") or [],
        diario.get("temperature_2m_min") or [],
    )
    if not atual or any(len(campo) < 4 for campo in campos_diarios):
        raise ValueError("A API não retornou a previsão completa.")

    nomes_dias = ("Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom")
    proximos_dias = []
    for indice in range(1, 4):
        data_dia = campos_diarios[0][indice]
        dia_semana = nomes_dias[date.fromisoformat(data_dia).weekday()]
        proximos_dias.append({
            "day": dia_semana,
            "code": int(campos_diarios[1][indice]),
            "max": int(round(float(campos_diarios[2][indice]))),
            "min": int(round(float(campos_diarios[3][indice]))),
        })

    return {
        "available": True,
        "city": cidade_exibicao,
        "requested_city": cidade_busca,
        "latitude": latitude,
        "longitude": longitude,
        "temperature": int(round(float(atual["temperature_2m"]))),
        "apparent_temperature": int(round(float(atual["apparent_temperature"]))),
        "humidity": int(round(float(atual["relative_humidity_2m"]))),
        "wind_speed": int(round(float(atual["wind_speed_10m"]))),
        "weather_code": int(atual["weather_code"]),
        "is_day": int(atual.get("is_day", 1)),
        "forecast": proximos_dias,
        "updated_at": time.time(),
        "stale": False,
        "error": "",
    }


# Os nomes abaixo correspondem aos arquivos estáticos publicados na documentação
# oficial dos ícones Weather do Google. Não há chamadas à Google Weather API.
def nome_icone_google(codigo, dia=True):
    """Mapeia WMO para os nomes de PNG estaticos listados pelo Google Weather."""
    if codigo == 0:
        return "sunny" if dia else "clear"
    if codigo == 1:
        return "mostly_sunny" if dia else "mostly_clear"
    if codigo == 2:
        return "partly_cloudy" if dia else "partly_clear"
    if codigo == 3:
        return "mostly_cloudy" if dia else "mostly_cloudy_night"
    if codigo in (45, 48):
        return "cloudy"
    if 51 <= codigo <= 55 or codigo == 61:
        return "drizzle"
    if codigo in (56, 57, 66, 67):
        return "wintry_mix"
    if codigo in (63, 80, 81):
        return "scattered_showers"
    if codigo in (65, 82):
        return "heavy"
    if codigo in (71, 77):
        return "flurries"
    if codigo in (73, 86):
        return "scattered_snow" if codigo == 73 else "heavy_snow"
    if codigo == 75:
        return "heavy_snow"
    if codigo == 85:
        return "snow_showers"
    if codigo == 95:
        return "isolated_tstorms"
    if codigo in (96, 99):
        return "strong_tstorms"
    return "cloudy"


def _baixar_icone_google(nome):
    """Baixa somente PNG Google valido, com transparencia de verdade."""
    from io import BytesIO
    from PIL import Image

    WEATHER_ICONS_DIR.mkdir(parents=True, exist_ok=True)
    destino = WEATHER_ICONS_DIR / f"{nome}_dark.png"
    if destino.exists() and destino.stat().st_size > 0:
        try:
            with Image.open(destino) as imagem:
                rgba = imagem.convert("RGBA")
                if imagem.format == "PNG" and rgba.getchannel("A").getextrema()[0] < 255:
                    return destino
        except Exception:
            pass
        destino.unlink(missing_ok=True)

    urls = [
        f"https://maps.gstatic.com/weather/v1/{nome}_dark.png",
        f"https://maps.gstatic.com/weather/v1/{nome}.png",
    ]
    ultimo_erro = None
    for url in urls:
        try:
            requisicao = Request(url, headers={"User-Agent": "PainelTFT/2.0.4"})
            with urlopen(requisicao, timeout=8) as resposta:
                conteudo = resposta.read(1024 * 1024 + 1)
            if not conteudo or len(conteudo) > 1024 * 1024:
                raise ValueError("PNG vazio ou maior que 1 MB.")
            with Image.open(BytesIO(conteudo)) as imagem:
                if imagem.format != "PNG":
                    raise ValueError("O servidor nao retornou um arquivo PNG.")
                rgba = imagem.convert("RGBA")
                alpha_min, alpha_max = rgba.getchannel("A").getextrema()
                if alpha_min == 255:
                    raise ValueError("O PNG nao possui pixels transparentes.")
                if rgba.width < 16 or rgba.height < 16:
                    raise ValueError("O PNG retornado tem dimensoes invalidas.")
            destino.write_bytes(conteudo)
            return destino
        except Exception as erro:
            ultimo_erro = erro
    raise RuntimeError(f"PNG Google '{nome}' invalido ou indisponivel: {ultimo_erro}")


def _fundo_clima_rgb():
    """Cor RGB exata equivalente ao RGB565 usado no fundo do display."""
    if CONFIG.get("weather_background") == "black":
        return (0, 0, 0)
    # RGB565 0x0063, preservando compatibilidade com o cache da V2.0.1.
    return (0, 12, 24)


def converter_icone_google(nome, tamanho, permitir_download=True):
    """Converte PNG Google com alfa real para RGB565 sobre a cor do display."""
    from PIL import Image

    caminho = WEATHER_ICONS_DIR / f"{nome}_dark.png"
    if permitir_download:
        caminho = _baixar_icone_google(nome)
    elif not caminho.exists():
        return b""

    fundo_rgb = _fundo_clima_rgb()
    with Image.open(caminho) as original:
        if original.format != "PNG":
            raise ValueError("O arquivo de icone nao e PNG.")
        imagem = original.convert("RGBA")
        if imagem.getchannel("A").getextrema()[0] == 255:
            raise ValueError("O PNG de icone nao tem transparencia real.")
        imagem.thumbnail((tamanho, tamanho), Image.Resampling.LANCZOS)
        # O TFT RGB565 nao tem canal alfa: mistura a transparencia com a cor
        # exata do fundo. Assim nao sobra um quadrado atras do desenho.
        fundo = Image.new("RGBA", (tamanho, tamanho), (*fundo_rgb, 255))
        posicao = ((tamanho - imagem.width) // 2, (tamanho - imagem.height) // 2)
        fundo.alpha_composite(imagem, posicao)
        rgb = fundo.convert("RGB")

    saida = bytearray(tamanho * tamanho * 2)
    posicao = 0
    for vermelho, verde, azul in rgb.getdata():
        pixel = ((vermelho & 0xF8) << 8) | ((verde & 0xFC) << 3) | (azul >> 3)
        saida[posicao] = pixel & 0xFF
        saida[posicao + 1] = (pixel >> 8) & 0xFF
        posicao += 2
    return bytes(saida)


def preparar_icones_clima(dados, permitir_download=True):
    global icones_clima_rgb565
    payloads = {0: b"", 1: b"", 2: b"", 3: b""}
    atual = nome_icone_google(int(dados.get("weather_code", 3)), bool(dados.get("is_day", 1)))
    try:
        payloads[0] = converter_icone_google(atual, 48, permitir_download)
    except Exception:
        payloads[0] = b""

    for indice, dia in enumerate(dados.get("forecast", [])[:3], start=1):
        nome = nome_icone_google(int(dia.get("code", 3)), True)
        try:
            payloads[indice] = converter_icone_google(nome, 24, permitir_download)
        except Exception:
            payloads[indice] = b""
    with trava_clima:
        icones_clima_rgb565 = payloads
    return payloads


def _enviar_icone_clima_serial(ser, slot, imagem_rgb565, versao):
    if not imagem_rgb565:
        return
    identificador = int((versao + slot + 1) % 999999) or 1
    tamanho = len(imagem_rgb565)
    ser.write(f"WICONSTART:{identificador}:{slot}:{tamanho}\n".encode("ascii"))
    tamanho_bloco = 54
    for deslocamento in range(0, tamanho, tamanho_bloco):
        bloco = imagem_rgb565[deslocamento:deslocamento + tamanho_bloco]
        texto = base64.b64encode(bloco).decode("ascii")
        ser.write(f"WICON:{identificador}:{deslocamento}:{texto}\n".encode("ascii"))
    ser.write(f"WICONEND:{identificador}\n".encode("ascii"))


def limpar_texto_alerta(valor, limite):
    texto = unicodedata.normalize("NFKD", str(valor or ""))
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    texto = " ".join(texto.replace("|", " ").replace("\n", " ").split())
    return texto.encode("ascii", "ignore").decode("ascii")[:limite]


def _lista_textos(valor):
    if valor is None:
        return []
    if isinstance(valor, list):
        return [str(item).strip() for item in valor if str(item).strip()]
    return [parte.strip() for parte in str(valor).split(",") if parte.strip()]


def _data_hora_inmet(data_texto, hora_texto, padrao):
    try:
        dia = str(data_texto or "")[:10]
        hora = str(hora_texto or padrao)[:5]
        return datetime.strptime(f"{dia} {hora}", "%Y-%m-%d %H:%M")
    except (TypeError, ValueError):
        return None


def buscar_alertas_inmet(cidade):
    """Obtém avisos ativos do INMET e mantém só os que citam o município escolhido."""
    partes = [parte.strip() for parte in cidade.split(",", 1)]
    municipio = normalizar_texto_clima(partes[0])
    uf = normalizar_texto_clima(partes[1]) if len(partes) > 1 else ""
    resposta = requisicao_json(INMET_ALERTS_URL, timeout=20)
    if not isinstance(resposta, dict):
        raise ValueError("Resposta inesperada do INMET.")

    agora = datetime.now(ZoneInfo("America/Sao_Paulo")).replace(tzinfo=None)
    por_id = {}
    for bloco in (resposta.get("hoje") or [], resposta.get("futuro") or []):
        for aviso in bloco:
            if not isinstance(aviso, dict):
                continue
            encerrado = aviso.get("encerrado")
            encerrado_texto = str(encerrado).strip().casefold()
            if encerrado is True or encerrado_texto in ("1", "true", "sim", "yes", "encerrado"):
                continue
            identificador = str(aviso.get("id_aviso") or aviso.get("id") or "")
            if not identificador:
                continue
            # A lista "hoje" vem antes de "futuro"; preserva o primeiro registro
            # quando o mesmo id aparece nas duas listas do feed.
            por_id.setdefault(identificador, aviso)

    encontrados = []
    for aviso in por_id.values():
        municipios = _lista_textos(aviso.get("municipios"))
        corresponde = False
        for item in municipios:
            normalizado = normalizar_texto_clima(item)
            if municipio and municipio in normalizado and (not uf or f"- {uf}" in normalizado):
                corresponde = True
                break
        if not corresponde:
            continue

        inicio = _data_hora_inmet(aviso.get("data_inicio"), aviso.get("hora_inicio"), "00:00")
        fim = _data_hora_inmet(aviso.get("data_fim"), aviso.get("hora_fim"), "23:59")
        if inicio and agora < inicio:
            continue
        if fim and agora > fim:
            continue

        severidade = str(aviso.get("severidade") or "").strip()
        severidade_norm = normalizar_texto_clima(severidade)
        if "grande perigo" in severidade_norm or "extreme" in severidade_norm:
            nivel = 3
        elif severidade_norm == "perigo" or "severe" in severidade_norm:
            nivel = 2
        else:
            nivel = 1

        riscos = _lista_textos(aviso.get("riscos"))
        detalhe = riscos[0] if riscos else str(aviso.get("descricao") or "Aviso meteorologico ativo.")
        valid_until = fim.strftime("%d/%m %H:%M") if fim else ""
        encontrados.append({
            "active": True,
            "severity": nivel,
            "severity_text": "Aviso ativo",
            "title": limpar_texto_alerta(aviso.get("descricao") or "Alerta meteorologico", 30),
            "detail": limpar_texto_alerta(detalhe, 68),
            "valid_until": valid_until,
            "updated_at": time.time(),
            "error": "",
            "source": "INMET",
            "id": identificador,
        })

    if not encontrados:
        return {
            "active": False, "severity": 0, "severity_text": "", "title": "",
            "detail": "", "valid_until": "", "updated_at": time.time(),
            "error": "Nenhum aviso ativo para este município.", "source": "INMET", "id": "",
        }
    encontrados.sort(key=lambda item: (-item["severity"], item["valid_until"]))
    return encontrados[0]


def comando_dados_clima(dados):
    cidade = limpar_texto_alerta(dados.get("city", "Sorocaba - SP"), 23) or "Sorocaba - SP"
    campos = [
        cidade,
        int(dados.get("temperature", 0) or 0),
        int(dados.get("apparent_temperature", 0) or 0),
        int(dados.get("humidity", 0) or 0),
        int(dados.get("wind_speed", 0) or 0),
        int(dados.get("weather_code", 3) or 3),
        int(dados.get("is_day", 1) or 0),
    ]
    previsao = list(dados.get("forecast", []))[:3]
    dias_padrao = ("Seg", "Ter", "Qua")
    for indice in range(3):
        dia = previsao[indice] if indice < len(previsao) else {}
        campos.extend([
            limpar_texto_alerta(dia.get("day", dias_padrao[indice]), 3) or dias_padrao[indice],
            int(dia.get("code", 3) or 3),
            int(dia.get("max", 0) or 0),
            int(dia.get("min", 0) or 0),
        ])
    return "WEATHER:" + "|".join(str(campo) for campo in campos) + "\n"

def comando_dados_alerta(dados):
    if not dados.get("active"):
        return "ALERT:0\n"
    campos = [
        1,
        int(dados.get("severity", 1)),
        limpar_texto_alerta(dados.get("title"), 30),
        limpar_texto_alerta(dados.get("detail"), 58),
        limpar_texto_alerta(dados.get("valid_until"), 16),
    ]
    return "ALERT:" + "|".join(str(campo) for campo in campos) + "\n"


def _salvar_cache_clima():
    with trava_clima:
        clima = dict(dados_clima)
        clima["forecast"] = [dict(dia) for dia in dados_clima.get("forecast", [])]
    with trava_alerta:
        alerta = dict(dados_alerta)
    try:
        WEATHER_CACHE_FILE.write_text(
            json.dumps({"weather": clima, "alert": alerta}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except OSError:
        pass


def carregar_cache_clima():
    if not WEATHER_CACHE_FILE.exists():
        return
    try:
        cache = json.loads(WEATHER_CACHE_FILE.read_text(encoding="utf-8"))
        clima = cache.get("weather")
        alerta = cache.get("alert")
        clima_cache = None
        cidade_configurada = CONFIG.get("weather_city", "Sorocaba, SP").strip().casefold()
        cidade_cache = str((clima or {}).get("requested_city") or cidade_configurada).strip().casefold()
        if isinstance(clima, dict) and clima.get("available") and cidade_cache == cidade_configurada:
            with trava_clima:
                dados_clima.update(clima)
                idade = time.time() - float(dados_clima.get("updated_at") or 0)
                dados_clima["stale"] = idade > 1800
                if dados_clima["stale"]:
                    dados_clima["error"] = "Exibindo a última previsão salva; aguardando atualização."
                clima_cache = dict(dados_clima)
                clima_cache["forecast"] = [dict(dia) for dia in dados_clima.get("forecast", [])]
        if clima_cache:
            # So le icones Google em cache; sem eles, a area fica limpa ate a proxima transferencia.
            preparar_icones_clima(clima_cache, permitir_download=False)
        if isinstance(alerta, dict):
            idade_alerta = time.time() - float(alerta.get("updated_at") or 0)
            with trava_alerta:
                if idade_alerta <= 600:
                    dados_alerta.update(alerta)
                else:
                    dados_alerta.update({
                        "active": False,
                        "severity": 0,
                        "title": "",
                        "detail": "",
                        "valid_until": "",
                        "updated_at": time.time(),
                        "error": "Sem validação recente do INMET; avisos ocultados até nova consulta.",
                        "source": "INMET",
                        "id": "",
                    })
    except (OSError, ValueError, TypeError):
        pass


def enviar_clima_para_esp():
    with trava_clima:
        dados = dict(dados_clima)
        dados["forecast"] = [dict(dia) for dia in dados_clima.get("forecast", [])]
        icones = dict(icones_clima_rgb565)
    with trava_alerta:
        alerta = dict(dados_alerta)

    if porta_serial is None or not porta_serial.is_open:
        return False

    with trava_serial:
        ser = porta_serial
        if ser is None or not ser.is_open:
            return False

        # A localização é enviada mesmo quando o display está em PC Monitor/Música/Work.
        localizacao = comando_localizacao_clima(dados)
        cidade_configurada = str(CONFIG.get("weather_city", "")).strip().casefold()
        cidade_da_leitura = str(dados.get("requested_city", "")).strip().casefold()
        if localizacao and cidade_configurada and cidade_da_leitura == cidade_configurada:
            ser.write(localizacao.encode("ascii", errors="ignore"))

        if modo_atual == "HOME" and dados.get("available"):
            ser.write(comando_dados_clima(dados).encode("ascii", errors="ignore"))
            versao = int((dados.get("updated_at") or time.time()) * 1000) % 999999
            for slot in range(4):
                imagem = icones.get(slot, b"")
                if imagem:
                    _enviar_icone_clima_serial(ser, slot, imagem, versao)
                else:
                    ser.write(f"WICONCLEAR:{slot}\n".encode("ascii"))
            ser.write(b"WEATHERICONSDONE\n")
            ser.write(comando_dados_alerta(alerta).encode("ascii", errors="ignore"))
        ser.flush()
    return True


def atualizar_clima():
    ultimo_fetch_clima = 0.0
    ultimo_fetch_alerta = 0.0
    ultima_cidade = ""
    while True:
        cidade = CONFIG.get("weather_city", "Sorocaba, SP")
        agora = time.monotonic()
        forcar = clima_force_event.is_set()
        buscar_previsao = forcar or (agora - ultimo_fetch_clima >= 1800) or cidade != ultima_cidade
        buscar_alerta = forcar or (agora - ultimo_fetch_alerta >= 600) or cidade != ultima_cidade

        if buscar_previsao:
            try:
                clima_novo = buscar_clima_open_meteo(cidade)
                icones_novos = preparar_icones_clima(clima_novo)
                with trava_clima:
                    dados_clima.update(clima_novo)
                ultimo_fetch_clima = time.monotonic()
                ultima_cidade = cidade
                _salvar_cache_clima()
                enviar_localizacao_clima_para_esp(clima_novo)
                enviar_clima_para_esp()
            except Exception as erro:
                with trava_clima:
                    dados_clima["error"] = str(erro)[:160]
                    if dados_clima.get("updated_at") is not None:
                        dados_clima["stale"] = True
                    else:
                        dados_clima["available"] = False
                ultimo_fetch_clima = time.monotonic() - 1500

        if buscar_alerta:
            try:
                alerta_novo = buscar_alertas_inmet(cidade)
                with trava_alerta:
                    dados_alerta.update(alerta_novo)
                ultimo_fetch_alerta = time.monotonic()
                _salvar_cache_clima()
                # Envia a atualização de alerta sem forçar redesenho da página atual.
                with trava_serial:
                    ser = porta_serial
                    if ser is not None and ser.is_open and modo_atual == "HOME":
                        ser.write(comando_dados_alerta(alerta_novo).encode("ascii", errors="ignore"))
                        ser.flush()
            except Exception as erro:
                with trava_alerta:
                    dados_alerta.update({
                        "active": False,
                        "severity": 0,
                        "title": "",
                        "detail": "",
                        "valid_until": "",
                        "updated_at": time.time(),
                        "error": f"Não foi possível validar os avisos do INMET: {str(erro)[:100]}",
                        "source": "INMET",
                        "id": "",
                    })
                    alerta_sem_validacao = dict(dados_alerta)
                _salvar_cache_clima()
                with trava_serial:
                    ser = porta_serial
                    if ser is not None and ser.is_open and modo_atual == "HOME":
                        ser.write(comando_dados_alerta(alerta_sem_validacao).encode("ascii", errors="ignore"))
                        ser.flush()
                ultimo_fetch_alerta = time.monotonic() - 540
        clima_force_event.clear()
        clima_force_event.wait(30)


def obter_dados_alerta():
    with trava_alerta:
        return dict(dados_alerta)


@app.get("/")
def inicio():
    return render_template("index.html")


@app.get("/api/ports")
def portas():
    itens = [{"device": p.device, "description": p.description} for p in list_ports.comports()]
    return jsonify(ports=itens)


@app.get("/api/status")
def status():
    conectado = porta_serial is not None and porta_serial.is_open
    with trava_config:
        controle = CONFIG["mode_control"]
    return jsonify(
        connected=conectado,
        port=porta_serial.port if conectado else "",
        mode=modo_atual,
        mode_control=controle,
        foreground_process=processo_atual,
        error=ultimo_erro,
        data=dados_monitor,
        music=obter_dados_musica(),
        work=obter_work_timer(),
        weather=obter_dados_clima(),
        alert=obter_dados_alerta(),
    )


def obter_dados_clima():
    with trava_clima:
        dados = dict(dados_clima)
        dados["forecast"] = [dict(dia) for dia in dados_clima.get("forecast", [])]
    return dados


@app.post("/api/weather/refresh")
def solicitar_atualizacao_clima():
    clima_force_event.set()
    return jsonify(requested=True, message="Atualização do clima solicitada.")


@app.get("/api/settings")
def obter_configuracoes():
    with trava_config:
        return jsonify(CONFIG)


@app.post("/api/settings")
def atualizar_configuracoes():
    global CONFIG
    dados = request.get_json(silent=True) or {}
    with trava_config:
        cidade_anterior = CONFIG.get("weather_city", "")
        fundo_anterior = CONFIG.get("weather_background", "navy")
        atualizado = dict(CONFIG)
        atualizado.update(dados)
        CONFIG = validar_configuracao(atualizado)
        cidade_nova = CONFIG.get("weather_city", "")
        fundo_novo = CONFIG.get("weather_background", "navy")
    if cidade_nova != cidade_anterior or fundo_novo != fundo_anterior:
        clima_force_event.set()
    with trava_work:
        estado = _atualizar_work_locked()
        if not estado["running"]:
            duracao = CONFIG["focus_minutes"] if work_timer["phase"] == "FOCO" else CONFIG["break_minutes"]
            work_timer["remaining"] = duracao * 60
            work_timer["total"] = duracao * 60
    try:
        salvar_configuracao()
        enviada = enviar_configuracao_para_esp()
        return jsonify(saved=True, sent_to_display=enviada, settings=CONFIG)
    except Exception as erro:
        return jsonify(saved=True, sent_to_display=False, warning=str(erro), settings=CONFIG)


@app.post("/api/connect")
def conectar():
    global porta_serial, modo_atual, ultimo_erro
    dados = request.get_json(silent=True) or {}
    porta = dados.get("port", "")
    portas_validas = {p.device for p in list_ports.comports()}
    if porta not in portas_validas:
        return jsonify(error="Porta COM inválida ou não encontrada."), 400

    try:
        with trava_serial:
            if porta_serial is not None and porta_serial.is_open:
                porta_serial.close()
            nova = serial.Serial()
            nova.port = porta
            nova.baudrate = 115200
            nova.timeout = 0.2
            nova.write_timeout = 1
            nova.dtr = False
            nova.rts = False
            nova.open()
            porta_serial = nova

        limite = time.monotonic() + 12
        while time.monotonic() < limite:
            try:
                enviar_e_aguardar("PING", "ACK:PONG", timeout=1)
                enviar_configuracao_para_esp()
                if CONFIG["mode_control"] == "manual":
                    enviar_e_aguardar("MODE:HOME", "ACK:MODE:HOME")
                    modo_atual = "HOME"
                if modo_atual == "HOME":
                    enviar_clima_para_esp()
                ultimo_erro = ""
                return jsonify(connected=True, port=porta)
            except RuntimeError:
                time.sleep(0.25)

        with trava_serial:
            if porta_serial is not None:
                porta_serial.close()
                porta_serial = None
        return jsonify(error="O ESP32 não respondeu. Grave o firmware incluído e feche o Monitor Serial."), 504
    except Exception as erro:
        with trava_serial:
            if porta_serial is not None:
                try:
                    porta_serial.close()
                except Exception:
                    pass
                porta_serial = None
        return jsonify(error=str(erro)), 500


@app.post("/api/disconnect")
def desconectar():
    global porta_serial, modo_atual
    with trava_serial:
        if porta_serial is not None:
            porta_serial.close()
            porta_serial = None
        modo_atual = "HOME"
    return jsonify(connected=False)


@app.post("/api/mode")
def modo():
    global modo_atual, CONFIG, forcar_sync_musica
    dados = request.get_json(silent=True) or {}
    nome = dados.get("mode", "")
    if nome not in ("HOME", "PCMON", "MUSIC", "WORK"):
        return jsonify(error="Modo inválido."), 400
    try:
        mudou_modo = modo_atual != nome
        if mudou_modo:
            enviar_e_aguardar(f"MODE:{nome}", f"ACK:MODE:{nome}")
            modo_atual = nome
            if nome == "MUSIC":
                forcar_sync_musica = True
            elif nome == "HOME":
                enviar_clima_para_esp()
        with trava_config:
            CONFIG["mode_control"] = "manual"
        salvar_configuracao()
        return jsonify(mode=nome, mode_control="manual")
    except Exception as erro:
        return jsonify(error=str(erro)), 503


@app.post("/api/test")
def testar_usb():
    try:
        enviar_e_aguardar("PING", "ACK:PONG")
        return jsonify(ok=True, message="Comunicação USB funcionando.")
    except Exception as erro:
        return jsonify(error=str(erro)), 503


@app.get("/api/work")
def obter_estado_work():
    return jsonify(obter_work_timer())


@app.post("/api/work/control")
def controlar_work():
    dados = request.get_json(silent=True) or {}
    acao = dados.get("action")
    with trava_work:
        estado = _atualizar_work_locked()
        if acao == "start":
            work_timer["running"] = True
            work_timer["last_tick"] = time.monotonic()
        elif acao == "pause":
            work_timer["running"] = False
        elif acao == "reset":
            work_timer["phase"] = "FOCO"
            work_timer["remaining"] = CONFIG["focus_minutes"] * 60
            work_timer["total"] = CONFIG["focus_minutes"] * 60
            work_timer["running"] = False
            work_timer["cycles"] = 0
        else:
            return jsonify(error="Ação de cronômetro inválida."), 400
        resposta = _atualizar_work_locked()
    return jsonify(work=resposta)


@app.get("/api/music")
def obter_estado_musica():
    return jsonify(obter_dados_musica())


@app.get("/api/music/cover")
def obter_capa_musica():
    with trava_musica:
        imagem = capa_musica_jpeg
        versao = versao_capa_musica
    if not imagem:
        return "", 404
    resposta = Response(imagem, mimetype="image/jpeg")
    resposta.headers["Cache-Control"] = "no-store"
    resposta.headers["X-Cover-Version"] = str(versao)
    return resposta


@app.post("/api/music/control")
def controlar_musica():
    dados = request.get_json(silent=True) or {}
    acao = dados.get("action")
    if acao not in ("toggle", "next", "previous"):
        return jsonify(error="Comando de mídia inválido."), 400
    try:
        asyncio.run(executar_comando_midia(acao))
        return jsonify(ok=True, music=obter_dados_musica())
    except ImportError:
        return jsonify(error="Integração de mídia do Windows não instalada. Execute configurar_dependencias.bat."), 503
    except Exception as erro:
        return jsonify(error=f"Não foi possível controlar a mídia: {erro}"), 503


def _limpar_texto_midia(texto, limite=28):
    texto = unicodedata.normalize("NFKD", str(texto or ""))
    texto = texto.encode("ascii", "ignore").decode("ascii")
    texto = texto.replace("|", " ").replace("\r", " ").replace("\n", " ")
    texto = re.sub(r"\s+", " ", texto).strip()
    return texto[:limite] or "-"


async def _ler_thumbnail_midia(thumbnail):
    if thumbnail is None:
        return None

    from winrt.windows.storage.streams import DataReader

    stream = None
    reader = None
    try:
        stream = await thumbnail.open_read_async()
        tamanho = int(stream.size)
        if tamanho <= 0 or tamanho > 8 * 1024 * 1024:
            return None

        reader = DataReader(stream.get_input_stream_at(0))
        await reader.load_async(tamanho)
        dados = bytearray(tamanho)
        reader.read_bytes(dados)
        return bytes(dados)
    except Exception:
        return None
    finally:
        if reader is not None:
            try:
                reader.close()
            except Exception:
                pass
        if stream is not None:
            try:
                stream.close()
            except Exception:
                pass


def _converter_capa(raw):
    if not raw:
        return b"", b""

    from PIL import Image, ImageOps

    try:
        with Image.open(io.BytesIO(raw)) as original:
            imagem = original.convert("RGB")
            capa_web = ImageOps.fit(
                imagem, (180, 180), method=Image.Resampling.LANCZOS
            )
            saida_web = io.BytesIO()
            capa_web.save(saida_web, format="JPEG", quality=86, optimize=True)

            capa_tft = ImageOps.fit(
                imagem, (128, 128), method=Image.Resampling.LANCZOS
            )
            bytes_rgb565 = bytearray(128 * 128 * 2)
            posicao = 0
            for vermelho, verde, azul in capa_tft.getdata():
                pixel = ((vermelho & 0xF8) << 8) | ((verde & 0xFC) << 3) | (azul >> 3)
                bytes_rgb565[posicao] = pixel & 0xFF
                bytes_rgb565[posicao + 1] = (pixel >> 8) & 0xFF
                posicao += 2

            return saida_web.getvalue(), bytes(bytes_rgb565)
    except Exception:
        return b"", b""


def _timespan_ms(valor):
    """Converte um Windows.Foundation.TimeSpan (datetime.timedelta) em ms."""
    if valor is None:
        return 0
    try:
        return max(0, int(valor.total_seconds() * 1000))
    except (AttributeError, TypeError, ValueError, OverflowError):
        return 0


async def _consultar_sessao_midia(chave_capa_atual=None, tentar_capa=False):
    from winrt.windows.media.control import (
        GlobalSystemMediaTransportControlsSessionManager,
        GlobalSystemMediaTransportControlsSessionPlaybackStatus,
    )

    manager = await GlobalSystemMediaTransportControlsSessionManager.request_async()
    sessao = manager.get_current_session()
    if sessao is None:
        return {
            "available": True,
            "playing": False,
            "title": "Nenhuma mídia",
            "artist": "Abra Spotify ou outro player",
            "album": "",
            "status": "SEM MIDIA",
            "position_ms": 0,
            "duration_ms": 0,
            "cover_key": "",
            "thumbnail_bytes": None,
        }

    propriedades = await sessao.try_get_media_properties_async()
    reproducao = sessao.get_playback_info()
    tocando = reproducao.playback_status == GlobalSystemMediaTransportControlsSessionPlaybackStatus.PLAYING

    # O Windows informa posição, início e fim da faixa pela linha do tempo da sessão.
    # Alguns players não publicam a duração; nesse caso, mantém os metadados e oculta o progresso.
    posicao_ms = 0
    duracao_ms = 0
    try:
        linha_tempo = sessao.get_timeline_properties()
        inicio_ms = _timespan_ms(linha_tempo.start_time)
        posicao_ms = max(0, _timespan_ms(linha_tempo.position) - inicio_ms)
        duracao_ms = max(0, _timespan_ms(linha_tempo.end_time) - inicio_ms)
        if duracao_ms:
            posicao_ms = min(posicao_ms, duracao_ms)
    except Exception:
        pass

    titulo_original = propriedades.title if propriedades else ""
    artista_original = propriedades.artist if propriedades else ""
    album_original = propriedades.album_title if propriedades else ""
    chave = "\x1f".join((titulo_original, artista_original, album_original))

    thumbnail_bytes = None
    if chave_capa_atual is not None and (chave != chave_capa_atual or tentar_capa):
        thumbnail_bytes = await _ler_thumbnail_midia(propriedades.thumbnail if propriedades else None)

    return {
        "available": True,
        "playing": bool(tocando),
        "title": _limpar_texto_midia(titulo_original, 28),
        "artist": _limpar_texto_midia(artista_original, 28),
        "album": _limpar_texto_midia(album_original, 48),
        "status": "TOCANDO" if tocando else "PAUSADO",
        "position_ms": posicao_ms,
        "duration_ms": duracao_ms,
        "cover_key": chave,
        "thumbnail_bytes": thumbnail_bytes,
    }


async def executar_comando_midia(acao):
    from winrt.windows.media.control import GlobalSystemMediaTransportControlsSessionManager

    manager = await GlobalSystemMediaTransportControlsSessionManager.request_async()
    sessao = manager.get_current_session()
    if sessao is None:
        raise RuntimeError("Nenhuma sessão de mídia ativa foi encontrada no Windows.")

    if acao == "toggle":
        await sessao.try_toggle_play_pause_async()
    elif acao == "next":
        await sessao.try_skip_next_async()
    elif acao == "previous":
        await sessao.try_skip_previous_async()
    leitura = await _consultar_sessao_midia()
    leitura.pop("cover_key", None)
    leitura.pop("thumbnail_bytes", None)
    return leitura


def obter_dados_musica():
    with trava_musica:
        return dict(dados_musica)


def _enviar_capa_serial(ser, imagem_rgb565, versao):
    if not imagem_rgb565:
        ser.write(b"COVERCLEAR\n")
        return

    identificador = int(versao % 999999) or 1
    tamanho = len(imagem_rgb565)
    ser.write(f"COVERSTART:{identificador}:{tamanho}\n".encode("ascii"))

    # 54 bytes viram exatamente 72 caracteres Base64 e cabem no buffer serial do ESP32.
    tamanho_bloco = 54
    for deslocamento in range(0, tamanho, tamanho_bloco):
        bloco = imagem_rgb565[deslocamento:deslocamento + tamanho_bloco]
        texto = base64.b64encode(bloco).decode("ascii")
        pacote = f"COVER:{identificador}:{deslocamento}:{texto}\n"
        ser.write(pacote.encode("ascii"))

    ser.write(f"COVEREND:{identificador}\n".encode("ascii"))
    ser.flush()


def atualizar_musica_windows():
    global dados_musica, capa_musica_jpeg, capa_musica_rgb565
    global versao_capa_musica, chave_capa_musica, ultima_tentativa_capa
    global forcar_sync_musica, ultimo_erro

    ultima_assinatura_enviada = None
    ultima_capa_enviada = -1

    while True:
        if modo_atual == "MUSIC":
            tentar_capa = False
            try:
                if os.name != "nt":
                    raise RuntimeError("A leitura de mídia está disponível somente no Windows.")

                with trava_musica:
                    chave_atual = chave_capa_musica
                    tem_capa = bool(capa_musica_rgb565)
                    tempo_ultima_tentativa = ultima_tentativa_capa

                tentar_capa = (not tem_capa and time.monotonic() - tempo_ultima_tentativa >= 30)
                leitura = asyncio.run(_consultar_sessao_midia(chave_atual, tentar_capa))
            except ImportError:
                leitura = {
                    "available": False,
                    "playing": False,
                    "title": "Integração ausente",
                    "artist": "Execute configurar_dependencias.bat",
                    "album": "",
                    "status": "SEM API",
                    "cover_key": "",
                    "thumbnail_bytes": None,
                }
            except Exception:
                leitura = {
                    "available": True,
                    "playing": False,
                    "title": "Sem sessão de mídia",
                    "artist": "Abra um player compatível",
                    "album": "",
                    "status": "SEM MIDIA",
                    "cover_key": "",
                    "thumbnail_bytes": None,
                }

            nova_chave = leitura.pop("cover_key", "")
            thumbnail_bytes = leitura.pop("thumbnail_bytes", None)
            with trava_musica:
                mudou_faixa = nova_chave != chave_capa_musica
                tentou_capa_agora = mudou_faixa or (tentar_capa and bool(nova_chave))
                if tentou_capa_agora:
                    ultima_tentativa_capa = time.monotonic()

                if mudou_faixa or thumbnail_bytes is not None or tentou_capa_agora:
                    jpeg, rgb565 = _converter_capa(thumbnail_bytes)
                    capa_musica_jpeg = jpeg
                    capa_musica_rgb565 = rgb565
                    chave_capa_musica = nova_chave
                    versao_capa_musica += 1

                leitura["cover_version"] = versao_capa_musica
                leitura["has_cover"] = bool(capa_musica_jpeg)
                dados_musica = leitura

                assinatura = (
                    bool(leitura.get("playing")),
                    leitura.get("status", ""),
                    leitura.get("title", ""),
                    leitura.get("artist", ""),
                )
                versao_capa = versao_capa_musica
                imagem_rgb565 = capa_musica_rgb565

            if forcar_sync_musica:
                ultima_assinatura_enviada = None
                ultima_capa_enviada = -1
                forcar_sync_musica = False

            titulo = _limpar_texto_midia(leitura.get("title", ""), 28)
            artista = _limpar_texto_midia(leitura.get("artist", ""), 28)
            estado = _limpar_texto_midia(leitura.get("status", "SEM MIDIA"), 14).upper()
            tocando = 1 if leitura.get("playing") else 0
            comando = f"MUSICDATA:{tocando}|{estado}|{titulo}|{artista}\n"
            posicao_ms = max(0, int(leitura.get("position_ms", 0)))
            duracao_ms = max(0, int(leitura.get("duration_ms", 0)))
            comando_tempo = f"MUSICTIME:{posicao_ms}|{duracao_ms}\n"

            try:
                with trava_serial:
                    ser = porta_serial
                    if modo_atual == "MUSIC" and ser is not None and ser.is_open:
                        if assinatura != ultima_assinatura_enviada:
                            ser.write(comando.encode("ascii", errors="ignore"))
                            ultima_assinatura_enviada = assinatura

                        # A linha de progresso é enviada separadamente, sem retransmitir metadados ou capa.
                        ser.write(comando_tempo.encode("ascii"))

                        if versao_capa != ultima_capa_enviada:
                            _enviar_capa_serial(ser, imagem_rgb565, versao_capa)
                            ultima_capa_enviada = versao_capa
            except Exception as erro:
                ultimo_erro = str(erro)

            time.sleep(2)
        else:
            time.sleep(1)

def enviar_dados_work():
    while True:
        if modo_atual == "WORK":
            estado = obter_work_timer()
            comando = (
                f"WORKDATA:{estado['phase']}|{estado['remaining']}|{estado['total']}|"
                f"{1 if estado['running'] else 0}|{estado['cycles']}\n"
            )
            try:
                with trava_serial:
                    if modo_atual == "WORK" and porta_serial is not None and porta_serial.is_open:
                        porta_serial.write(comando.encode("ascii"))
            except Exception as erro:
                global ultimo_erro
                ultimo_erro = str(erro)
            time.sleep(1)
        else:
            time.sleep(1)


def calcular_uso_gpu(amostras, exigir_nome_gpu=True):
    grupos = {}
    valores = []
    for caminho, valor in amostras:
        nome = caminho.lower()
        if exigir_nome_gpu and "gpu engine(" not in nome:
            continue
        valor = max(0.0, valor)
        valores.append(valor)
        engine = re.search(r"engtype_([^)]*)", nome) or re.search(r"_eng_([^)]*)", nome)
        fisica = re.search(r"phys_(\d+)", nome)
        if engine:
            gpu_id = fisica.group(1) if fisica else "0"
            tipo_engine = engine.group(1).split("_")[0]
            chave = (gpu_id, tipo_engine)
            grupos[chave] = grupos.get(chave, 0.0) + valor
    if grupos:
        uso = max(grupos.values())
    elif valores:
        uso = max(valores)
    else:
        return -1
    return min(100, max(0, int(round(uso))))


def ler_gpu_typeperf():
    resultado = subprocess.run(
        ["typeperf", r"\GPU Engine(*)\Utilization Percentage", "-sc", "1"],
        capture_output=True, text=True, timeout=5,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), check=False,
    )
    if resultado.returncode != 0 or not resultado.stdout.strip():
        return -1
    linhas = list(csv.reader(resultado.stdout.splitlines()))
    if len(linhas) < 2:
        return -1
    amostras = []
    for caminho, texto in zip(linhas[0][1:], linhas[-1][1:]):
        try:
            amostras.append((caminho, float(texto.strip().replace(",", "."))))
        except ValueError:
            continue
    return calcular_uso_gpu(amostras, exigir_nome_gpu=True)


def ler_gpu_powershell():
    script = r"""
$sets = Get-Counter -ListSet * -ErrorAction SilentlyContinue
$paths = @($sets | Where-Object { $_.CounterSetName -match '(?i)GPU|Graphics|Gráf|Video|Mecanismo' } | ForEach-Object { $_.PathsWithInstances } | Where-Object { $_ -match '(?i)utiliza|utilisa|percent|porcent|uso' })
if ($paths.Count -eq 0) { exit 2 }
$samples = Get-Counter -Counter $paths -MaxSamples 1 -ErrorAction Stop
foreach ($sample in $samples.CounterSamples) {
  $value = $sample.CookedValue.ToString([Globalization.CultureInfo]::InvariantCulture)
  [Console]::WriteLine($sample.Path + "`t" + $value)
}
"""
    resultado = subprocess.run(
        ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script],
        capture_output=True, text=True, timeout=8,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), check=False,
    )
    if resultado.returncode != 0 or not resultado.stdout.strip():
        return -1
    amostras = []
    for linha in resultado.stdout.splitlines():
        partes = linha.rsplit("\t", 1)
        if len(partes) == 2:
            try:
                amostras.append((partes[0], float(partes[1].strip().replace(",", "."))))
            except ValueError:
                pass
    return calcular_uso_gpu(amostras, exigir_nome_gpu=False)


def ler_gpu_windows():
    if os.name != "nt":
        return -1
    try:
        valor = ler_gpu_typeperf()
        if valor >= 0:
            return valor
    except (OSError, subprocess.SubprocessError, csv.Error):
        pass
    try:
        return ler_gpu_powershell()
    except (OSError, subprocess.SubprocessError):
        return -1


gpu_percentual = -1
gpu_trava = threading.Lock()


def atualizar_gpu():
    global gpu_percentual
    while True:
        if modo_atual == "PCMON":
            try:
                valor = ler_gpu_windows()
                with gpu_trava:
                    gpu_percentual = valor
            except Exception:
                pass
            intervalo = CONFIG["gpu_interval"]
            time.sleep(intervalo)
        else:
            time.sleep(2)


def obter_gpu_percentual():
    with gpu_trava:
        return gpu_percentual


def obter_processo_em_uso():
    if os.name != "nt":
        return "-"
    try:
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        user32.GetForegroundWindow.restype = ctypes.c_void_p
        user32.GetWindowThreadProcessId.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
        user32.GetWindowThreadProcessId.restype = ctypes.c_ulong
        janela = user32.GetForegroundWindow()
        pid = ctypes.c_ulong()
        user32.GetWindowThreadProcessId(janela, ctypes.byref(pid))
        if not pid.value:
            return "-"
        return psutil.Process(pid.value).name()
    except Exception:
        return "-"


def escolher_modo_automatico(nome_processo):
    nome = nome_processo.lower()
    for regra in CONFIG["rules"]:
        alvo = regra["process"].lower()
        if alvo and (nome == alvo or nome.endswith("\\" + alvo)):
            return regra["mode"]
    return CONFIG["fallback_mode"]


def monitorar_aplicativo_ativo():
    global processo_atual, modo_atual, ultimo_erro, forcar_sync_musica
    while True:
        processo = obter_processo_em_uso()
        processo_atual = processo
        if CONFIG["mode_control"] == "automatic":
            destino = escolher_modo_automatico(processo)
            if destino != modo_atual and porta_serial is not None and porta_serial.is_open:
                try:
                    enviar_e_aguardar(f"MODE:{destino}", f"ACK:MODE:{destino}")
                    modo_atual = destino
                    if destino == "MUSIC":
                        forcar_sync_musica = True
                    elif destino == "HOME":
                        enviar_clima_para_esp()
                    ultimo_erro = ""
                except Exception as erro:
                    ultimo_erro = str(erro)
        time.sleep(1.5)


def enviar_monitoramento():
    global dados_monitor
    psutil.cpu_percent(interval=None)
    ultimo_trafego = psutil.net_io_counters()
    ultima_leitura = time.monotonic()
    while True:
        intervalo = CONFIG["data_interval"]
        time.sleep(intervalo)
        if modo_atual != "PCMON":
            ultimo_trafego = psutil.net_io_counters()
            ultima_leitura = time.monotonic()
            continue
        try:
            cpu = int(round(psutil.cpu_percent(interval=None)))
            memoria = psutil.virtual_memory()
            trafego = psutil.net_io_counters()
            agora = time.monotonic()
            delta = max(agora - ultima_leitura, 0.1)
            download = max(0, (trafego.bytes_recv - ultimo_trafego.bytes_recv) / delta / (1024 * 1024))
            upload = max(0, (trafego.bytes_sent - ultimo_trafego.bytes_sent) / delta / (1024 * 1024))
            ultimo_trafego = trafego
            ultima_leitura = agora
            unidade = os.environ.get("SystemDrive", "C:")
            caminho_disco = unidade + "\\" if os.name == "nt" else "/"
            disco = psutil.disk_usage(caminho_disco)
            uptime_seg = max(0, int(time.time() - psutil.boot_time()))
            dias, resto = divmod(uptime_seg, 86400)
            horas, minutos = divmod(resto, 3600)[0], (resto % 3600) // 60
            gpu = obter_gpu_percentual()
            dados_monitor = {
                "cpu": cpu,
                "gpu": gpu,
                "ram_percent": int(memoria.percent),
                "ram_used_gb": round(memoria.used / (1024 ** 3), 1),
                "ram_total_gb": round(memoria.total / (1024 ** 3), 1),
                "download_mbps": round(download, 2),
                "upload_mbps": round(upload, 2),
                "disk_free_gb": round(disco.free / (1024 ** 3), 1),
                "uptime": f"{dias}d {horas:02d}h {minutos:02d}m",
                "updated_at": time.time(),
            }
            # Mantem o protocolo PCDATA da V1.4 para nao quebrar o firmware anterior.
            ram_used_mb = int(memoria.used / (1024 * 1024))
            ram_total_mb = int(memoria.total / (1024 * 1024))
            disk_free_mb = int(disco.free / (1024 * 1024))
            uptime_min = int(uptime_seg / 60)
            down_kbps = int(download * 1024)
            up_kbps = int(upload * 1024)
            comando = f"PCDATA:{cpu},{ram_used_mb},{ram_total_mb},{down_kbps},{up_kbps},{disk_free_mb},{uptime_min},{gpu}\n"
            with trava_serial:
                if modo_atual == "PCMON" and porta_serial is not None and porta_serial.is_open:
                    porta_serial.write(comando.encode("ascii"))
        except Exception as erro:
            ultimo_erro = str(erro)


if __name__ == "__main__":
    carregar_cache_clima()
    threading.Thread(target=atualizar_gpu, daemon=True, name="monitoramento-gpu").start()
    threading.Thread(target=enviar_monitoramento, daemon=True, name="monitoramento-pc").start()
    threading.Thread(target=monitorar_aplicativo_ativo, daemon=True, name="automacao-aplicativos").start()
    threading.Thread(target=atualizar_musica_windows, daemon=True, name="integracao-midia").start()
    threading.Thread(target=enviar_dados_work, daemon=True, name="cronometro-work").start()
    threading.Thread(target=atualizar_clima, daemon=True, name="previsao-clima").start()
    print("Painel TFT disponível em http://127.0.0.1:5000")
    print("Feche o Monitor Serial da Arduino IDE enquanto o site usar a porta COM.")
    app.run(host="127.0.0.1", port=5000, debug=False, use_reloader=False)
