Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
pasta = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = pasta

' pyw inicia o Python sem abrir uma janela de terminal.
shell.Run "pyw -3 app.py", 0, False

' Aguarda o servidor iniciar antes de abrir o navegador.
WScript.Sleep 2500
shell.Run "http://127.0.0.1:5000", 1, False
