@echo off
cd /d "%~dp0"
echo Instalando as dependencias do Painel TFT (incluindo imagem de album)...
py -3 -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Falha ao instalar as dependencias principais. Verifique o Python e o comando py.
  pause
  exit /b 1
)

echo.
echo Verificando suporte a integracao de midia e leitura de capas do Windows...
py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)"
if errorlevel 1 (
  echo Python anterior ao 3.11: os modos principais funcionam, mas o modo Musica precisa de Python 3.11 ou superior.
) else (
  py -3 -m pip install "winrt-Windows.Media.Control>=4.0.0" winrt-Windows.Storage.Streams
  if errorlevel 1 (
    echo Nao foi possivel instalar a integracao de midia. O modo Musica ficara indisponivel, mas os outros modos continuam funcionando.
  )
)

echo.
echo Configuracao concluida. Execute iniciar_em_segundo_plano.vbs.
pause
